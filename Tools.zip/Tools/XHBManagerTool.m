//
//  XHBManagerTool.m
//  LeTao
//
//  Created by ClarkXu on 16/6/2.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "XHBManagerTool.h"

@implementation XHBManagerTool
//前提：从plist文件中读数据；数组嵌套字典的样式
- (NSArray *)getAndParseWithPlistFile:(NSString *)plistFileName withClass:(Class)modelClass {
    //plist路径(文件名不一样)
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:plistFileName ofType:nil];
    //从plist读取数据
    NSArray *plistArray = [NSArray arrayWithContentsOfFile:plistPath];
    NSArray *returnArray = [self getArrayWithArray:plistArray withClass:modelClass];
    return returnArray;
}
//把数组中的字典循环转成模型对象，并返回数组
- (NSArray *)getArrayWithArray:(NSArray *)array withClass:(Class)modelClass {
    //将字典转成模型对象(类型不一样); 返回
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        id model = [modelClass new];
        //KVC转换
        [model setValuesForKeysWithDictionary:dic];
        [mutableArray addObject:model];
    }
    return [mutableArray copy];
}

@end
