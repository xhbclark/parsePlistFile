//
//  XHBManagerTool.h
//  LeTao
//
//  Created by ClarkXu on 16/6/2.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XHBManagerTool : NSObject

@end
